void realview_clk_init(void __iomem *sysbase, bool is_pb1176);
