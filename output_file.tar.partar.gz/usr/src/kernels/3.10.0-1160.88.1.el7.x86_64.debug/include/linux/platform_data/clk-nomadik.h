/* Minimal platform data header */
void nomadik_clk_init(void);
