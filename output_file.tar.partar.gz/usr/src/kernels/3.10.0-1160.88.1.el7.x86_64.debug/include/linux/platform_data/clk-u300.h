void __init u300_clk_init(void __iomem *base);
