#ifndef __ASM_ARCH_PXA930_TRKBALL_H
#define __ASM_ARCH_PXA930_TRKBALL_H

struct pxa930_trkball_platform_data {
	int x_filter;
	int y_filter;
};

#endif /* __ASM_ARCH_PXA930_TRKBALL_H */

