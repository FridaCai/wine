#ifndef __LINUX_TSL2563_H
#define __LINUX_TSL2563_H

struct tsl2563_platform_data {
	int cover_comp_gain;
};

#endif /* __LINUX_TSL2563_H */
