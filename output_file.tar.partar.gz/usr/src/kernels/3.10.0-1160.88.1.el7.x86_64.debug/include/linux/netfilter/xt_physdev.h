#ifndef _XT_PHYSDEV_H
#define _XT_PHYSDEV_H

#include <linux/if.h>
#include <uapi/linux/netfilter/xt_physdev.h>

#endif /*_XT_PHYSDEV_H*/
